#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
ROOT="$(cd "$ROOT" && pwd)"

# Change app-name strings in Android string resources where the upstream key is recognized.
python3 - "$ROOT" <<'PY'
from pathlib import Path
import sys, re
root = Path(sys.argv[1])
resource_dirs = list(root.glob("**/src/main/res/values"))
changed = 0
for d in resource_dirs:
    for p in d.glob("strings.xml"):
        s = p.read_text(encoding="utf-8")
        new = s
        # Common Android app-name keys.
        new = re.sub(
            r'(<string\s+name="(?:app_name|application_name|launcher_name)"[^>]*>).*?(</string>)',
            r'\1Yefti Launcher\2',
            new,
            flags=re.S
        )
        if new != s:
            p.write_text(new, encoding="utf-8")
            print(f"Updated app name: {p.relative_to(root)}")
            changed += 1

# Set known primary/accent color names to Minecraft green if present.
green_names = {"colorPrimary", "colorPrimaryDark", "colorAccent", "md_green_700", "md_green_500"}
for d in resource_dirs:
    for p in d.glob("colors.xml"):
        s = p.read_text(encoding="utf-8")
        new = s
        for name in green_names:
            new = re.sub(
                rf'(<color\s+name="{re.escape(name)}"[^>]*>).*?(</color>)',
                r'\g<1>#2E7D32\2',
                new,
                flags=re.S
            )
        if new != s:
            p.write_text(new, encoding="utf-8")
            print(f"Applied best-effort green palette: {p.relative_to(root)}")
            changed += 1

print(f"Rebrand pass complete; resource files changed: {changed}")
print("Review resources manually; upstream UI may use additional theme definitions.")
PY
