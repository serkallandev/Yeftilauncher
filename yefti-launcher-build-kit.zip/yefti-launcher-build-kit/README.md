# Yefti Launcher — Android build kit

This repository is a **rebranding/build kit**, not a prebuilt APK. It uses the open-source Amethyst Android launcher (the successor to PojavLauncher) as the runtime foundation. Amethyst already contains the complex Android Java runtime, rendering, version launching, and mod-loader integration that a new launcher would otherwise need to implement.

Upstream project: https://github.com/AngelAuraMC/Amethyst-Android  
Upstream license: GNU LGPL v3. Read and comply with the upstream license and all third-party notices before redistributing builds.

## What this kit does

- Downloads the upstream source (including submodules) during a GitHub Actions build.
- Changes Android app display-name resources to **Yefti Launcher** where recognized.
- Applies a best-effort Minecraft-green theme resource update where matching color resources are present.
- Builds a debug APK using the upstream Gradle task.
- Uploads the APK and a ZIP of the rebranded source as GitHub Actions artifacts.

## What it does not claim

- No APK has been built or device-tested by this kit at the time it was generated.
- This is not an independently implemented launcher engine. Runtime features come from upstream and depend on the upstream version/device.
- The package/application ID is intentionally left unchanged to avoid breaking native integrations; this is a rebrand build, not yet a separately installable parallel app alongside Amethyst.
- Microsoft sign-in, offline use, version compatibility, Fabric/Forge support, rendering backends, and mod management must be checked against upstream behavior and tested on your device.
- Do not use this to bypass Minecraft ownership or authentication. Use a legitimate Microsoft account flow and a valid Minecraft Java Edition license for online play.

## Build from your Android phone using GitHub

1. Create a GitHub repository named `yefti-launcher-build-kit`.
2. Upload all files from this ZIP, including the hidden `.github` folder.
3. Open the repository's **Actions** tab.
4. Enable Actions if GitHub asks, then select **Build Yefti Launcher APK** and tap **Run workflow**.
5. When the run completes successfully, open that run and download the `yefti-launcher-apk-and-source` artifact.
6. Extract the artifact ZIP. It contains the APK and `yefti-launcher-source.zip`.

If the workflow fails, open the failed job and inspect its logs; upstream dependencies or Android build tooling may change over time.

## Local build (PC)

Requirements: Git, JDK compatible with upstream Gradle, Android SDK/NDK components required by upstream, and network access.

```bash
git clone --recursive https://github.com/AngelAuraMC/Amethyst-Android.git
cd Amethyst-Android
bash ../yefti-launcher-build-kit/scripts/rebrand.sh .
./gradlew :app_pojavlauncher:assembleDebug
```

The debug APK should be produced at:
`app_pojavlauncher/build/outputs/apk/debug/`

The exact output path can change upstream. Review the source and license before distributing.
